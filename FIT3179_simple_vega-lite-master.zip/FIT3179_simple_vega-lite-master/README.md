# FIT3179_simple_vega-lite
A basic example that embeds a Vega-Lite chart in a HTML page with Vega-Embed: https://github.com/vega/vega-embed
The example is accessible at https://berniejenny.github.io/FIT3179_simple_vega-lite/
